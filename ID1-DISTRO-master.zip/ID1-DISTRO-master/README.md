
# PROJECT TITLE : ID1-DISTRO


## Installation

INSTALL OUR-ISO WITH GOOGLE DRIVE :

```bash
 https://drive.google.com/drive/folders/1VeTROvg9IiEC3-J82hqW3G4ZuoV2A7nh?usp=sharing
 

```
## Demo


![Texte alternatif](target.png)
    
## Authors

- [@ELhadratiOth](https://www.github.com/ELhadratiOth)
- [@hajarelkamri](https://github.com/hajarelkamri)
- [@khayyihanae](https://github.com/khayyihanae)
- [@kpatc](https://github.com/kpatc)
- [@Hanangharibi](https://github.com/GitHub380Hanan)




